//
//  ViewController.swift
//  TableView Section Headers
//
//  Created by Memo on 1/11/19.
//  Copyright © 2019 Membriux. All rights reserved.
//

// –––––    Comment    –––––
// –––––    TODO:    –––––

import UIKit




class CitiesViewController: UIViewController {

    // ––––– TODO: Connect TableView outlet
    
    
    
    let data = [("Arizona", ["Phoenix"]),
                ("California", ["Los Angeles", "San Francisco", "San Jose", "San Diego"]),
                ("Florida", ["Miami", "Jacksonville"]),
                ("Illinois", ["Chicago"]),
                ("New York", ["Buffalo", "New York"]),
                ("Pennsylvania", ["Pittsburg", "Philadelphia"]),
                ("Texas", ["Houston", "San Antonio", "Dallas", "Austin", "Fort Worth"])]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // ––––– TODO: Assign tableView.datasource to VC
        
        
        // ––––– TODO: Assign tableView.delegate to VC
        
        
        // ––––– TODO: Refresh tableView
        
    }
    
    

    // –––––  TODO: Add Table View Functions

    
    
    

}

