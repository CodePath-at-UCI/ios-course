

## UITableView Section Headers Steps
**1. Create TableView**
* Connect to CitiesViewController
*  Set tableView delegate and datasource
*  Add tableView functions

**2. Add CityCell**
* Add cell and label to tableView
* Connect cell and label to CityCell
* Don’t forget the cell identifier

**3. Connect data with TableView**
* Add code to tableView Functions


**4. (Bonus) Add Section Headers**



**Tutorials:**

– [Section Header Tutorial](https://guides.codepath.com/ios/Table-View-Guide#working-with-sections)


– [UISearchBarTutorial](https://guides.codepath.com/ios/Search-Bar-Guide#working-with-uisearchbars-directly)

