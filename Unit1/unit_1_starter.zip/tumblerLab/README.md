

## TumblrLab Starter Project Steps 

**1. Get posts (json)**

**2. Configure TableView Cells**
* Install CocoaPods and Alamofire
* Add UIImageView to cell 
* Connect UIImageView to PostCell
