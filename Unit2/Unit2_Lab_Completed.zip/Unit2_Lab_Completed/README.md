#Overview
This is a starter project for Unit 2 lab of Codepath's iOS University.

####Main objective
Extend upon part 1 Tumblr, the previous lab assignment. In part 1, students were intructed to create a network request to the Tumblr API to display photos on a simple tableview. In this lab(part 2), students will learn about segues and understand how to pass information between view controllers by implenting an additional details view controller.
