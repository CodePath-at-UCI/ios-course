//
//  aViewController.swift
//  TumblrLab
//
//  Created by Derek Chang on 1/31/20.
//  Copyright © 2020 Lily Pham. All rights reserved.
//

import UIKit

class aViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
